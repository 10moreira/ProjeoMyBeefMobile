package mateusmoreira.appmybeefbeta;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {

    EditText editText3emailLogin;
    Button button3Login, buttonCriaLogin;
    private Cursor cursor;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        editText3emailLogin = (EditText) findViewById(R.id.editText3emailLogin);

        button3Login = (Button) findViewById(R.id.button3Login);
        buttonCriaLogin = (Button) findViewById(R.id.buttonCriaLogin);


        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


            }
        });
    }

    public void abrirCriarLogin(View v) {

        startActivity(new Intent(getBaseContext(), UsuarioActivity.class));
    }


    public void abrirLogin(View v) {

        if (editText3emailLogin.getText().toString().length() <= 0) {
            Toast.makeText(getApplication(), "Não deixe seu login em branco!!", Toast.LENGTH_LONG).show();
            editText3emailLogin.requestFocus();
        }
    }


    @Override
    public void onClick(View v) {


    }


    public void verificarLogin(View view) {

        EditText editText3emailLogin = (EditText) findViewById(R.id.editText3emailLogin);

        if (editText3emailLogin.getText().toString().length() <= 0) {
            editText3emailLogin.setError("Prencha com seu email!");

        } else {

            startActivity(new Intent(getBaseContext(), PropriedadeActivity.class));

           // SQLiteDatabase db = openOrCreateDatabase("DBappMyBeef.sqlite", Context.MODE_PRIVATE, null);
           // Cursor cursor = db.rawQuery("SELECT email FROM usuario", new String[]{editText3emailLogin.toString()});

        }
    }

    /*
    public void validaLogin(View v) {

        DataSourceUsuario database = new DataSourceUsuario(this, "DBappMyBeef.sqlite", null, 1);
        SQLiteDatabase db = database.getWritableDatabase();
        String email = editText3emailLogin.getText().toString();

        cursor = db.rawQuery("select email from usuario where email='"+email+"'", null);

        if (cursor.moveToFirst()){
            String usua=cursor.getString(0);

            if(email.equals(usua)) {
                startActivity(new Intent(getBaseContext(), PropriedadeActivity.class));
                editText3emailLogin.setText("");
            }
        }
    }
*/

}