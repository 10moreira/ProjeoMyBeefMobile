package mateusmoreira.appmybeefbeta;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import Daos.PropriedadeDAO;
import Domain.Propriedade;

public class PropriedadeActivity extends AppCompatActivity implements View.OnClickListener {


     EditText editTextnomePropriedade, editText10NomeLocalidade,
             editText8CidadePropriedade, editText9TipoPropriedade, editText5data;
    Spinner spinnerpaisPropriedade,  spinnerUf, spinnerTipoPropriedade, spinnermunicipio;
     Button button6Enviar, button7Cancelar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_propriedade);




        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(
                this, R.array.usuarioUF, android.R.layout.simple_spinner_item);
        spinnerUf = (Spinner) findViewById(R.id.spinnerUF);
        spinnerUf.setAdapter(adapter1);


        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this, R.array.spinnerpaisPropriedade, android.R.layout.simple_spinner_item);
        spinnerpaisPropriedade = (Spinner) findViewById(R.id.spinnerpaisPropriedade);
        spinnerpaisPropriedade.setAdapter(adapter);


        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(
                this, R.array.spinnerTipoPropriedade, android.R.layout.simple_spinner_item);
        spinnerTipoPropriedade = (Spinner) findViewById(R.id.spinnerTipoPropriedade);
        spinnerTipoPropriedade.setAdapter(adapter2);



        ArrayAdapter<CharSequence> adapter3 = ArrayAdapter.createFromResource(
                this, R.array.spinnermunicipio, android.R.layout.simple_spinner_item);
        spinnermunicipio = (Spinner) findViewById(R.id.spinnermunicipio);
        spinnermunicipio.setAdapter(adapter3);


        editTextnomePropriedade = (EditText) findViewById(R.id.editTextnomePropriedade);
        editText10NomeLocalidade = (EditText) findViewById(R.id.editText10NomeLocalidade);
        editText5data = (EditText) findViewById(R.id.editText5data);

        button6Enviar = (Button) findViewById(R.id.button6Enviar);
        button7Cancelar = (Button) findViewById(R.id.button7Cancelar);

        button6Enviar.setOnClickListener(this);
        button7Cancelar.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {

        switch (v.getId()){
            case R.id.button6Enviar:
                Propriedade propriedade =  new Propriedade();
                propriedade.setNomepropriedade(editTextnomePropriedade.getText().toString());
                propriedade.setLocalidade(editText10NomeLocalidade.getText().toString());
                propriedade.setMunicipio(spinnermunicipio.getSelectedItem().toString());
                propriedade.setPais(spinnerpaisPropriedade.getSelectedItem().toString());
                propriedade.setUf(spinnerUf.getSelectedItem().toString());
                propriedade.setTipoPropriedade(spinnerTipoPropriedade.getSelectedItem().toString());
                propriedade.setDatasimulacao(editText5data.getText().toString());

                PropriedadeDAO dao = new PropriedadeDAO(getApplicationContext());

                if(dao.salvarpropriedade(propriedade)){
                    Toast.makeText(getApplication(), "Propriedade cadastrada com sucesso!!", Toast.LENGTH_LONG).show();
                    startActivity(new Intent(this, SimulacaoActivity.class));
                    finish();

                }else{

                    Toast.makeText(getApplication(), "Erro ao gravar Propriedade", Toast.LENGTH_LONG).show();
                }

                break;

            case R.id.button7Cancelar:
                botaoCancelapropriedade();

                break;

        }

    }


    public void botaoCancelapropriedade(){

            editTextnomePropriedade.setText(null);
            editText10NomeLocalidade.setText(null);
            editText5data.setText(null);

        startActivity(new Intent(getBaseContext(), LoginActivity.class));

    }




}


