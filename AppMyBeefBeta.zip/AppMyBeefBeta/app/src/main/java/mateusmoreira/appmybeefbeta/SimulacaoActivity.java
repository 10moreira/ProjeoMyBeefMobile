package mateusmoreira.appmybeefbeta;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.interfaces.datasets.IBarDataSet;

import java.util.ArrayList;

public class SimulacaoActivity extends AppCompatActivity {

    private BarChart chart;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_simulacao);

    //     BarChart chart;
      //  Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
       // setSupportActionBar(toolbar);

       // FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
       // fab.setOnClickListener(new View.OnClickListener() {
         //   @Override
           // public void onClick(View view) {
             //   Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
               //         .setAction("Action", null).show();

               chart=(BarChart)findViewById(R.id.chart);
        ArrayList<String> xAxis=new ArrayList<>();
        ArrayList<IBarDataSet> dataSets=null;
        ArrayList<BarEntry> valueSet = new ArrayList<>();

        xAxis.add("Mateus");
        xAxis.add("Mario");
        xAxis.add("João");

        valueSet.add(new BarEntry(25, 0));
        valueSet.add(new BarEntry(50, 1));
        valueSet.add(new BarEntry(40, 2));

        BarDataSet barDataSet =  new BarDataSet(valueSet, "nomes");

        barDataSet.setColors(new int[]{Color.BLUE, Color.BLACK,Color.RED });

        dataSets=new ArrayList<>();
        dataSets.add(barDataSet);

        YAxis yAxisRight=chart.getAxisRight();
        yAxisRight.setEnabled(false);

        BarData data=new BarData(xAxis, dataSets);
        chart.setExtraOffsets(0, 0, 0, 20);
        chart.setData(data);
        chart.animateXY(2000, 2000);
        chart.invalidate();

            }
      //  });
    //}

}
